kubectl apply -f deployment.yaml

kubectl apply -f service.yaml


Replace <IMAGE URL> with proper image url
